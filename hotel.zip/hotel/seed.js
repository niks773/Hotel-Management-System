const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables
dotenv.config({ path: path.join(__dirname, '.env') });

// Import models
const User = require('./models/User');
const Room = require('./models/Room');

// Database Connection
async function connect() {
  try {
    await mongoose.connect(process.env.DB_URI || 'mongodb://localhost:27017/hotel_management', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✓ Database connected');
  } catch (error) {
    console.error('✗ Database connection error:', error);
    process.exit(1);
  }
}

// Seed users
async function seedUsers() {
  try {
    // Clear existing users
    await User.deleteMany({});
    console.log('✓ Cleared existing users');

    const hashedPassword = await bcrypt.hash('password123', 10);

    const users = [
      {
        name: 'Admin User',
        email: 'admin@hotel.com',
        password: hashedPassword,
        phone: '1234567890',
        role: 'admin',
        isActive: true
      },
      {
        name: 'Receptionist',
        email: 'receptionist@hotel.com',
        password: hashedPassword,
        phone: '1234567891',
        role: 'receptionist',
        isActive: true
      },
      {
        name: 'Staff Member',
        email: 'staff@hotel.com',
        password: hashedPassword,
        phone: '1234567892',
        role: 'staff',
        isActive: true
      },
      {
        name: 'Guest User',
        email: 'guest@hotel.com',
        password: hashedPassword,
        phone: '1234567893',
        role: 'guest',
        isActive: true
      }
    ];

    await User.insertMany(users);
    console.log('✓ Created 4 test users');
    console.log('  - admin@hotel.com (Admin)');
    console.log('  - receptionist@hotel.com (Receptionist)');
    console.log('  - staff@hotel.com (Staff)');
    console.log('  - guest@hotel.com (Guest)');
    console.log('  Password: password123');
  } catch (error) {
    console.error('✗ Error seeding users:', error);
  }
}

// Seed rooms
async function seedRooms() {
  try {
    // Clear existing rooms
    await Room.deleteMany({});
    console.log('✓ Cleared existing rooms');

    const rooms = [
      {
        roomNumber: '101',
        roomType: 'single',
        capacity: 1,
        price: 50,
        status: 'available',
        floorNumber: 1,
        amenities: ['WiFi', 'AC', 'TV'],
        description: 'Cozy single room'
      },
      {
        roomNumber: '102',
        roomType: 'double',
        capacity: 2,
        price: 75,
        status: 'available',
        floorNumber: 1,
        amenities: ['WiFi', 'AC', 'TV', 'Bath'],
        description: 'Comfortable double room'
      },
      {
        roomNumber: '201',
        roomType: 'suite',
        capacity: 4,
        price: 120,
        status: 'occupied',
        floorNumber: 2,
        amenities: ['WiFi', 'AC', 'TV', 'Kitchen', 'Dining'],
        description: 'Luxury suite with kitchen'
      },
      {
        roomNumber: '202',
        roomType: 'deluxe',
        capacity: 2,
        price: 100,
        status: 'available',
        floorNumber: 2,
        amenities: ['WiFi', 'AC', 'TV', 'Gym', 'Spa'],
        description: 'Deluxe room with spa access'
      },
      {
        roomNumber: '301',
        roomType: 'penthouse',
        capacity: 6,
        price: 250,
        status: 'available',
        floorNumber: 3,
        amenities: ['WiFi', 'AC', 'TV', 'Kitchen', 'Jacuzzi', 'Terrace'],
        description: 'Premium penthouse with all amenities'
      }
    ];

    await Room.insertMany(rooms);
    console.log('✓ Created 5 test rooms');
  } catch (error) {
    console.error('✗ Error seeding rooms:', error);
  }
}

// Main function
async function seed() {
  await connect();
  await seedUsers();
  await seedRooms();
  console.log('\n✓ Database seeded successfully!\n');
  process.exit(0);
}

// Run seed
seed().catch((error) => {
  console.error('✗ Seed error:', error);
  process.exit(1);
});
