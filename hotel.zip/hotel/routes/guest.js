const express = require('express');
const router = express.Router();
const guestController = require('../controllers/guestController');
const auth = require('../middleware/auth');
const role = require('../middleware/role');

router.use(auth);
router.use(role(['guest']));

// My Bookings
router.get('/bookings', guestController.getMyBookings);
router.post('/bookings', guestController.createBooking);
router.delete('/bookings/:id', guestController.cancelBooking);

// Available Rooms
router.get('/rooms/available', guestController.getAvailableRooms);

// Reviews
router.post('/reviews', guestController.submitReview);

// Services
router.post('/services/request', guestController.requestService);

module.exports = router;
