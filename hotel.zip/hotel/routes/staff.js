const express = require('express');
const router = express.Router();
const staffController = require('../controllers/staffController');
const auth = require('../middleware/auth');
const role = require('../middleware/role');

router.use(auth);
router.use(role(['staff', 'admin']));

// Tasks
router.get('/tasks', staffController.getAssignedTasks);
router.put('/tasks/:id', staffController.updateTaskStatus);

// Profile
router.get('/profile', staffController.getStaffProfile);

// History
router.get('/history', staffController.getMaintenanceHistory);

module.exports = router;
