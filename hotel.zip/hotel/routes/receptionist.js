const express = require('express');
const router = express.Router();
const receptionistController = require('../controllers/receptionistController');
const auth = require('../middleware/auth');
const role = require('../middleware/role');

router.use(auth);
router.use(role(['receptionist', 'admin']));

router.get('/dashboard', receptionistController.getDashboard);

// Booking Management
router.get('/bookings', receptionistController.getAllBookings);
router.get('/bookings/:id', receptionistController.getBookingById);
router.post('/bookings/:id/check-in', receptionistController.checkInGuest);
router.post('/bookings/:id/check-out', receptionistController.checkOutGuest);

// Services
router.get('/services', receptionistController.getAllServices);

// Payments
router.post('/payments', receptionistController.processPayment);
router.get('/payments/:bookingId', receptionistController.getPaymentsByBooking);

module.exports = router;
