const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const auth = require('../middleware/auth');
const role = require('../middleware/role');

router.use(auth);
router.use(role(['admin']));

router.get('/dashboard', adminController.getDashboard);

// User Management
router.get('/users', adminController.getAllUsers);
router.delete('/users/:id', adminController.deleteUser);

// Room Management
router.get('/rooms', adminController.getAllRooms);
router.post('/rooms', adminController.createRoom);
router.put('/rooms/:id', adminController.updateRoom);
router.delete('/rooms/:id', adminController.deleteRoom);

// Reports
router.get('/reports/financial', adminController.getFinancialReport);
router.get('/reports/occupancy', adminController.getOccupancyReport);

// Attendance Management
router.get('/attendance', adminController.getAllAttendance);
router.post('/attendance', adminController.markAttendance);
router.put('/attendance/:id', adminController.updateAttendance);

module.exports = router;
