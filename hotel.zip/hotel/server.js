const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');
const session = require('express-session');
const bcrypt = require('bcryptjs');

// Load environment variables
dotenv.config();

const app = express();

// Database Connection
const db = require('./config/db');
const Room = require('./models/Room');
const User = require('./models/User');
const Booking = require('./models/Booking');
const Payment = require('./models/Payment');
db.connect();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Session Configuration
app.use(session({
  secret: process.env.JWT_SECRET || 'secret_key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

// View Engine Setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use((req, res, next) => {
  res.locals.user = req.session?.user || null;
  next();
});

const protectedPagePaths = [
  '/dashboard',
  '/bookings',
  '/rooms',
  '/guests',
  '/services',
  '/reports',
  '/settings',
  '/profile',
  '/admin'
];

app.use((req, res, next) => {
  const publicPaths = ['/', '/login', '/register', '/logout'];
  const isPublicAsset = req.path.startsWith('/css') || req.path.startsWith('/js') || req.path.startsWith('/uploads');
  const isPublicApi = req.path.startsWith('/api/auth');
  const isProtectedPage = protectedPagePaths.some((path) => req.path === path || req.path.startsWith(path + '/'));

  if (publicPaths.includes(req.path) || isPublicAsset || isPublicApi || req.path === '/favicon.ico') {
    return next();
  }

  if (isProtectedPage && !req.session?.user) {
    return res.redirect('/login');
  }

  next();
});

// Page Routes
app.get('/', (req, res) => {
  res.redirect('/login');
});

app.get('/login', (req, res) => {
  res.render('auth/login');
});

app.get('/register', (req, res) => {
  res.render('auth/register');
});

app.get('/dashboard', (req, res) => {
  res.render('dashboard');
});

app.get('/bookings', (req, res) => {
  res.render('bookings');
});

app.get('/rooms', (req, res) => {
  res.render('rooms');
});

app.get('/guests', (req, res) => {
  res.render('guests');
});

app.get('/services', (req, res) => {
  res.render('services');
});

app.get('/reports', (req, res) => {
  res.render('reports');
});

app.get('/settings', (req, res) => {
  res.render('settings');
});

app.get('/profile', (req, res) => {
  res.render('auth/profile');
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

app.get('/admin', (req, res) => {
  res.redirect('/admin/rooms');
});

app.get('/admin/rooms', async (req, res) => {
  try {
    const rooms = await Room.find().sort({ createdAt: -1 });
    const availableRooms = await Room.countDocuments({ status: 'available' });
    const occupiedRooms = await Room.countDocuments({ status: 'occupied' });
    const maintenanceRooms = await Room.countDocuments({ status: 'maintenance' });
    res.render('admin/rooms', { rooms, availableRooms, occupiedRooms, maintenanceRooms });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.get('/admin/rooms/:id/edit', async (req, res) => {
  try {
    const room = await Room.findById(req.params.id);
    if (!room) {
      return res.status(404).send('Room not found');
    }
    res.render('admin/room-form', { room });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.post('/admin/rooms', async (req, res) => {
  try {
    const room = new Room(req.body);
    await room.save();
    res.redirect('/admin/rooms');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.post('/admin/rooms/:id', async (req, res) => {
  try {
    await Room.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.redirect('/admin/rooms');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.post('/admin/users', async (req, res) => {
  try {
    const { name, email, password, phone, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ name, email, password: hashedPassword, phone, role: role || 'guest' });
    await user.save();
    res.redirect('/admin/users');
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.get('/admin/users', async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    const totalUsers = await User.countDocuments();
    const activeUsers = await User.countDocuments({ isActive: true });
    const adminUsers = await User.countDocuments({ role: 'admin' });
    res.render('admin/users', { users, totalUsers, activeUsers, adminUsers });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.get('/admin/reports', async (req, res) => {
  try {
    const totalRooms = await Room.countDocuments();
    const occupiedRooms = await Room.countDocuments({ status: 'occupied' });
    const availableRooms = await Room.countDocuments({ status: 'available' });
    const maintenanceRooms = await Room.countDocuments({ status: 'maintenance' });
    const totalBookings = await Booking.countDocuments();
    const revenue = await Payment.aggregate([
      { $match: { status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    res.render('admin/reports', {
      totalRooms,
      occupiedRooms,
      availableRooms,
      maintenanceRooms,
      totalBookings,
      revenue: revenue[0]?.total || 0
    });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/receptionist', require('./routes/receptionist'));
app.use('/api/guest', require('./routes/guest'));
app.use('/api/staff', require('./routes/staff'));

// Error Handling - 404
app.use((req, res) => {
  res.status(404).render('404');
});

// Start Server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
