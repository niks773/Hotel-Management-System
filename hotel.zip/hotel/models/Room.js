const mongoose = require('mongoose');

const roomSchema = new mongoose.Schema({
  roomNumber: { type: String, required: true, unique: true },
  roomType: { 
    type: String, 
    enum: ['single', 'double', 'suite', 'deluxe', 'penthouse'],
    required: true 
  },
  capacity: { type: Number, required: true },
  price: { type: Number, required: true },
  status: { 
    type: String, 
    enum: ['available', 'occupied', 'maintenance', 'reserved'],
    default: 'available'
  },
  amenities: [String],
  floorNumber: { type: Number },
  description: String,
  images: [String],
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Room', roomSchema);
