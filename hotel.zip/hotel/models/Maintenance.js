const mongoose = require('mongoose');

const maintenanceSchema = new mongoose.Schema({
  roomId: { type: mongoose.Schema.Types.ObjectId, ref: 'Room', required: true },
  issueType: { 
    type: String, 
    enum: ['plumbing', 'electrical', 'hvac', 'furniture', 'cleaning', 'other'],
    required: true 
  },
  description: { type: String, required: true },
  status: { 
    type: String, 
    enum: ['pending', 'in-progress', 'completed'],
    default: 'pending'
  },
  priority: { 
    type: String, 
    enum: ['low', 'medium', 'high'],
    default: 'medium'
  },
  assignedStaffId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  reportedDate: { type: Date, default: Date.now },
  completedDate: Date,
  notes: String
});

module.exports = mongoose.model('Maintenance', maintenanceSchema);
