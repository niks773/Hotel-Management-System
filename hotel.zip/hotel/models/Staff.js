const mongoose = require('mongoose');

const staffSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  department: { 
    type: String, 
    enum: ['housekeeping', 'maintenance', 'kitchen', 'front-desk', 'security', 'management'],
    required: true 
  },
  position: String,
  salary: Number,
  joinDate: { type: Date, default: Date.now },
  isActive: { type: Boolean, default: true },
  experience: Number,
  qualifications: [String],
  contactNumber: String,
  address: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Staff', staffSchema);
