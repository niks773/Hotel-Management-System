const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
  staffId: { type: mongoose.Schema.Types.ObjectId, ref: 'Staff', required: true },
  staffName: { type: String, required: true },
  department: {
    type: String,
    enum: ['housekeeping', 'maintenance', 'kitchen', 'front-desk', 'security', 'management'],
    required: true
  },
  date: { type: Date, required: true, default: Date.now },
  status: {
    type: String,
    enum: ['present', 'absent', 'late', 'half-day'],
    default: 'present'
  },
  checkIn: { type: String },
  checkOut: { type: String },
  notes: { type: String },
  createdAt: { type: Date, default: Date.now }
});

// Compound index to prevent duplicate attendance for same staff on same day
attendanceSchema.index({ staffId: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('Attendance', attendanceSchema);

