// Authentication
function login() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  fetch('/api/auth/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ email, password })
  })
  .then(response => response.json())
  .then(data => {
    if (data.token) {
      localStorage.setItem('token', data.token);
      window.location.href = '/dashboard';
    } else {
      alert('Login failed: ' + data.message);
    }
  })
  .catch(error => console.error('Error:', error));
}

function logout() {
  localStorage.removeItem('token');
  window.location.href = '/login';
}

// User Management
function deleteUser(userId) {
  if (confirm('Are you sure you want to delete this user?')) {
    fetch(`/api/admin/users/${userId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': 'Bearer ' + localStorage.getItem('token')
      }
    })
    .then(response => response.json())
    .then(data => {
      alert(data.message);
      location.reload();
    })
    .catch(error => console.error('Error:', error));
  }
}

function openAddUserModal() {
  const section = document.getElementById('userFormSection');
  if (section) {
    section.style.display = 'block';
    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

// Room Management
function deleteRoom(roomId) {
  if (confirm('Are you sure you want to delete this room?')) {
    fetch(`/api/admin/rooms/${roomId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': 'Bearer ' + localStorage.getItem('token')
      }
    })
    .then(response => response.json())
    .then(data => {
      alert(data.message);
      location.reload();
    })
    .catch(error => console.error('Error:', error));
  }
}

function editRoom(roomId) {
  window.location.href = `/admin/rooms/${roomId}/edit`;
}

function openAddRoomModal() {
  const section = document.getElementById('roomFormSection');
  if (section) {
    section.style.display = 'block';
    section.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

// Booking Management
function viewBooking(bookingId) {
  window.location.href = `/api/receptionist/bookings/${bookingId}`;
}

function cancelBooking(bookingId) {
  if (confirm('Are you sure you want to cancel this booking?')) {
    fetch(`/api/guest/bookings/${bookingId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': 'Bearer ' + localStorage.getItem('token')
      }
    })
    .then(response => response.json())
    .then(data => {
      alert(data.message);
      location.reload();
    })
    .catch(error => console.error('Error:', error));
  }
}

// Task Management
function updateTaskStatus(taskId, status) {
  fetch(`/api/staff/tasks/${taskId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    },
    body: JSON.stringify({ status })
  })
  .then(response => response.json())
  .then(data => {
    alert(data.message);
    location.reload();
  })
  .catch(error => console.error('Error:', error));
}

// Get Authorization Token
function getAuthToken() {
  return localStorage.getItem('token');
}

// Check if user is logged in
function checkAuth() {
  const token = getAuthToken();
  if (!token && window.location.pathname !== '/login' && window.location.pathname !== '/register') {
    window.location.href = '/login';
  }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  checkAuth();
});

// Format Date
function formatDate(date) {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
}

// Format Currency
function formatCurrency(amount) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(amount);
}
