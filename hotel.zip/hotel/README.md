# Hotel Management System

A comprehensive Node.js and Express-based hotel management system with MongoDB integration, featuring role-based access control, room management, booking system, staff management, and financial tracking.

## Project Structure

```
hotel/
├── config/
│   └── db.js                 # Database connection configuration
├── controllers/
│   ├── authController.js     # Authentication logic
│   ├── adminController.js    # Admin operations
│   ├── receptionistController.js  # Receptionist operations
│   ├── guestController.js    # Guest operations
│   └── staffController.js    # Staff operations
├── models/
│   ├── User.js              # User schema
│   ├── Room.js              # Room schema
│   ├── Booking.js           # Booking schema
│   ├── Payment.js           # Payment schema
│   ├── Service.js           # Service schema
│   ├── Review.js            # Review schema
│   ├── Maintenance.js       # Maintenance schema
│   └── Staff.js             # Staff schema
├── routes/
│   ├── auth.js              # Authentication routes
│   ├── admin.js             # Admin routes
│   ├── receptionist.js      # Receptionist routes
│   ├── guest.js             # Guest routes
│   └── staff.js             # Staff routes
├── middleware/
│   ├── auth.js              # JWT authentication middleware
│   └── role.js              # Role-based access control
├── views/
│   ├── layouts/
│   │   ├── main.ejs         # Main layout with sidebar
│   │   └── auth.ejs         # Authentication layout
│   ├── partials/
│   │   ├── sidebar.ejs      # Navigation sidebar
│   │   └── topbar.ejs       # Top navigation bar
│   ├── auth/
│   │   ├── login.ejs        # Login page
│   │   └── profile.ejs      # User profile page
│   ├── admin/
│   │   ├── dashboard.ejs    # Admin dashboard
│   │   ├── users.ejs        # User management
│   │   ├── user-form.ejs    # User form
│   │   ├── rooms.ejs        # Room management
│   │   ├── fees.ejs         # Payment management
│   │   ├── fee-detail.ejs   # Payment details
│   │   ├── leads.ejs        # Guest leads
│   │   ├── attendance.ejs   # Staff attendance
│   │   └── reports.ejs      # Reports
│   ├── receptionist/
│   │   └── bookings.ejs     # Booking management
│   ├── guest/
│   │   └── bookings.ejs     # Guest bookings
│   ├── staff/
│   │   ├── dashboard.ejs    # Staff dashboard
│   │   ├── tasks.ejs        # Maintenance tasks
│   │   └── attendance-history.ejs  # Attendance history
│   ├── 404.ejs              # 404 error page
│   ├── 403.ejs              # 403 forbidden page
│   └── 500.ejs              # 500 server error page
├── public/
│   ├── css/
│   │   └── main.css         # Main stylesheet
│   ├── js/
│   │   └── main.js          # Main JavaScript
│   └── uploads/             # File uploads directory
├── server.js                # Express server entry point
├── package.json             # Project dependencies
├── .env                     # Environment configuration
└── README.md               # This file
```

## Features

### User Roles

1. **Admin**
   - View comprehensive dashboard with statistics
   - Manage all users (create, edit, delete)
   - Manage rooms (create, edit, delete, update status)
   - View financial and occupancy reports

2. **Receptionist**
   - View today's check-ins/check-outs
   - Manage all bookings
   - Process check-ins and check-outs
   - Handle payments and service requests
   - View available services

3. **Guest**
   - View my bookings
   - Create new bookings
   - Cancel bookings
   - Browse available rooms
   - Submit reviews
   - Request services

4. **Staff**
   - View assigned maintenance tasks
   - Update task status
   - View maintenance history
   - Access staff profile

### Core Models

#### User
- Authentication and profile management
- Role-based access control
- User status tracking

#### Room
- Room inventory management
- Status tracking (available, occupied, maintenance, reserved)
- Room types and pricing
- Amenities and capacity

#### Booking
- Guest booking management
- Check-in/check-out tracking
- Payment status monitoring
- Special requests handling

#### Payment
- Payment recording
- Multiple payment methods
- Transaction tracking
- Payment status management

#### Service
- Available hotel services
- Service pricing
- Service categorization

#### Review
- Guest reviews and ratings
- Multiple rating categories
- Review publishing control

#### Maintenance
- Maintenance request tracking
- Issue categorization
- Priority levels
- Staff assignment

#### Staff
- Staff information management
- Department tracking
- Salary and position management
- Qualifications and experience

## Setup Instructions

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (local or Atlas)
- npm or yarn

### Installation

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Configure Environment Variables**
   
   Create a `.env` file in the project root:
   ```
   PORT=3000
   DB_URI=mongodb://localhost:27017/hotel_management
   JWT_SECRET=your_jwt_secret_key_here
   NODE_ENV=development
   ```

3. **Start MongoDB**
   ```bash
   # If using local MongoDB
   mongod
   ```

4. **Run the Server**
   ```bash
   # Development mode with auto-reload
   npm run dev
   
   # Production mode
   npm start
   ```

5. **Access the Application**
   - Open browser and navigate to `http://localhost:3000`

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/profile` - Update user profile

### Admin
- `GET /api/admin/dashboard` - Admin dashboard stats
- `GET /api/admin/users` - Get all users
- `DELETE /api/admin/users/:id` - Delete user
- `GET /api/admin/rooms` - Get all rooms
- `POST /api/admin/rooms` - Create room
- `PUT /api/admin/rooms/:id` - Update room
- `DELETE /api/admin/rooms/:id` - Delete room
- `GET /api/admin/reports/financial` - Financial report
- `GET /api/admin/reports/occupancy` - Occupancy report

### Receptionist
- `GET /api/receptionist/dashboard` - Dashboard stats
- `GET /api/receptionist/bookings` - Get all bookings
- `GET /api/receptionist/bookings/:id` - Get booking details
- `POST /api/receptionist/bookings/:id/check-in` - Check-in guest
- `POST /api/receptionist/bookings/:id/check-out` - Check-out guest
- `GET /api/receptionist/services` - Get available services
- `POST /api/receptionist/payments` - Process payment
- `GET /api/receptionist/payments/:bookingId` - Get booking payments

### Guest
- `GET /api/guest/bookings` - Get my bookings
- `POST /api/guest/bookings` - Create booking
- `DELETE /api/guest/bookings/:id` - Cancel booking
- `GET /api/guest/rooms/available` - Get available rooms
- `POST /api/guest/reviews` - Submit review
- `POST /api/guest/services/request` - Request service

### Staff
- `GET /api/staff/tasks` - Get assigned tasks
- `PUT /api/staff/tasks/:id` - Update task status
- `GET /api/staff/profile` - Get staff profile
- `GET /api/staff/history` - Get maintenance history

## Authentication

The system uses JWT (JSON Web Tokens) for authentication:

1. User logs in with email and password
2. Server returns JWT token
3. Client stores token in localStorage
4. Subsequent requests include token in `Authorization: Bearer <token>` header
5. Server verifies token before processing requests

## Security Features

- Password hashing using bcryptjs
- JWT-based authentication
- Role-based access control (RBAC)
- Input validation
- Protected API endpoints

## Future Enhancements

- Email notifications for bookings
- SMS alerts
- Payment gateway integration
- Advanced reporting and analytics
- Room image gallery
- Guest communication portal
- Mobile app integration
- Multi-language support
- Two-factor authentication
- Inventory management

## Troubleshooting

### Database Connection Error
- Ensure MongoDB is running
- Check DB_URI in .env file
- Verify database credentials

### JWT Token Errors
- Check JWT_SECRET in .env
- Ensure token is included in request headers
- Verify token hasn't expired

### Port Already in Use
- Change PORT in .env file
- Or kill the process using the port

## Support

For issues or questions, please contact the development team.

## License

ISC
