const Booking = require('../models/Booking');
const Room = require('../models/Room');
const Payment = require('../models/Payment');
const Service = require('../models/Service');

// Dashboard
exports.getDashboard = async (req, res) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayBookings = await Booking.countDocuments({
      checkInDate: { $gte: today, $lt: new Date(today.getTime() + 24 * 60 * 60 * 1000) }
    });
    const checkOuts = await Booking.countDocuments({
      checkOutDate: { $gte: today, $lt: new Date(today.getTime() + 24 * 60 * 60 * 1000) }
    });
    const totalGuests = await Booking.countDocuments({
      status: { $in: ['checked-in', 'confirmed'] }
    });
    const totalRevenue = await Payment.aggregate([
      { $match: { status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    res.json({ 
      todayBookings, 
      checkOuts,
      totalGuests,
      totalRevenue: totalRevenue[0]?.total || 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Manage Bookings
exports.getAllBookings = async (req, res) => {
  try {
    const bookings = await Booking.find().populate('guestId').populate('roomId');
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getBookingById = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate('guestId').populate('roomId');
    res.json(booking);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.checkInGuest = async (req, res) => {
  try {
    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      { status: 'checked-in' },
      { new: true }
    );
    
    await Room.findByIdAndUpdate(booking.roomId, { status: 'occupied' });
    res.json({ message: 'Guest checked in', booking });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.checkOutGuest = async (req, res) => {
  try {
    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      { status: 'checked-out' },
      { new: true }
    );
    
    await Room.findByIdAndUpdate(booking.roomId, { status: 'available' });
    res.json({ message: 'Guest checked out', booking });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Manage Services
exports.getAllServices = async (req, res) => {
  try {
    const services = await Service.find({ isActive: true });
    res.json(services);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Manage Payments
exports.processPayment = async (req, res) => {
  try {
    const payment = new Payment(req.body);
    await payment.save();
    
    if (payment.status === 'completed') {
      await Booking.findByIdAndUpdate(
        payment.bookingId,
        { paymentStatus: 'paid' }
      );
    }
    
    res.status(201).json({ message: 'Payment processed', payment });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getPaymentsByBooking = async (req, res) => {
  try {
    const payments = await Payment.find({ bookingId: req.params.bookingId });
    res.json(payments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
