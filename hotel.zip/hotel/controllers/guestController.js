const Booking = require('../models/Booking');
const Room = require('../models/Room');
const Review = require('../models/Review');
const Service = require('../models/Service');

// View Bookings
exports.getMyBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ guestId: req.user.id }).populate('roomId');
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Create Booking
exports.createBooking = async (req, res) => {
  try {
    const { roomId, checkInDate, checkOutDate, numberOfGuests, specialRequests } = req.body;
    
    const room = await Room.findById(roomId);
    if (!room || room.status !== 'available') {
      return res.status(400).json({ message: 'Room not available' });
    }

    const nights = Math.ceil((new Date(checkOutDate) - new Date(checkInDate)) / (1000 * 60 * 60 * 24));
    const totalAmount = room.price * nights;

    const booking = new Booking({
      guestId: req.user.id,
      roomId,
      checkInDate,
      checkOutDate,
      numberOfGuests,
      totalAmount,
      specialRequests,
      bookingReference: 'BK' + Date.now()
    });

    await booking.save();
    await Room.findByIdAndUpdate(roomId, { status: 'reserved' });
    
    res.status(201).json({ message: 'Booking created', booking });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Cancel Booking
exports.cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    
    if (booking.guestId.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Unauthorized' });
    }

    if (booking.status !== 'pending' && booking.status !== 'confirmed') {
      return res.status(400).json({ message: 'Cannot cancel booking' });
    }

    await Booking.findByIdAndUpdate(req.params.id, { status: 'cancelled' });
    await Room.findByIdAndUpdate(booking.roomId, { status: 'available' });
    
    res.json({ message: 'Booking cancelled' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// View Available Rooms
exports.getAvailableRooms = async (req, res) => {
  try {
    const { checkInDate, checkOutDate } = req.query;
    
    const rooms = await Room.find({ status: 'available' });
    res.json(rooms);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Submit Review
exports.submitReview = async (req, res) => {
  try {
    const review = new Review({
      guestId: req.user.id,
      ...req.body
    });
    await review.save();
    res.status(201).json({ message: 'Review submitted', review });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Request Service
exports.requestService = async (req, res) => {
  try {
    const { serviceId, bookingId } = req.body;
    
    const service = await Service.findById(serviceId);
    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }

    res.json({ message: 'Service request created', service });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
