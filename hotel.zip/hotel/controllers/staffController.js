const Maintenance = require('../models/Maintenance');
const Room = require('../models/Room');
const Staff = require('../models/Staff');

// Get Tasks
exports.getAssignedTasks = async (req, res) => {
  try {
    const tasks = await Maintenance.find({ 
      assignedStaffId: req.user.id,
      status: { $ne: 'completed' }
    }).populate('roomId');
    
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Update Task Status
exports.updateTaskStatus = async (req, res) => {
  try {
    const { status } = req.body;
    
    const task = await Maintenance.findByIdAndUpdate(
      req.params.id,
      { 
        status,
        completedDate: status === 'completed' ? Date.now() : null
      },
      { new: true }
    );

    if (status === 'completed') {
      await Room.findByIdAndUpdate(task.roomId, { status: 'available' });
    }

    res.json({ message: 'Task updated', task });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// Get Staff Info
exports.getStaffProfile = async (req, res) => {
  try {
    const staff = await Staff.findOne({ userId: req.user.id });
    res.json(staff);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// View Maintenance History
exports.getMaintenanceHistory = async (req, res) => {
  try {
    const history = await Maintenance.find({ assignedStaffId: req.user.id }).populate('roomId');
    res.json(history);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
